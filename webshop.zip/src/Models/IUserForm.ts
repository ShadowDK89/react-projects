export interface IUserForm{
    firstName:string;
    lastName:string;
    paymentMethod:string;
}