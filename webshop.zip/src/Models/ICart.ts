export interface ICart{
    id: number;
    name: string;
    imageUrl: string;
    quantity: number;
    price: number;
}